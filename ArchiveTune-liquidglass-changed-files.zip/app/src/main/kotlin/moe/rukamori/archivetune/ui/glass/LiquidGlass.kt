/*
 * ArchiveTune - Liquid Glass module
 *
 * Real backdrop refraction using a GraphicsLayer + AGSL RuntimeShader (Android 13+).
 * Android 12 (API 31-32): blur only. Older: translucent fallback.
 */

package moe.rukamori.archivetune.ui.glass

import android.graphics.RenderEffect as AndroidRenderEffect
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.RenderEffect
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.toIntSize

/** Holds the recorded layer of "what is behind the glass". */
@Stable
class GlassBackdrop(
    val layer: GraphicsLayer,
) {
    var coordinates: LayoutCoordinates? = null
    var hasContent: Boolean = false
}

val LocalGlassBackdrop = staticCompositionLocalOf<GlassBackdrop?> { null }

@Composable
fun rememberGlassBackdrop(): GlassBackdrop {
    val layer = rememberGraphicsLayer()
    return remember(layer) { GlassBackdrop(layer) }
}

/** Marks this composable's content as something glass elements can refract. */
fun Modifier.glassSource(backdrop: GlassBackdrop): Modifier =
    this
        .onGloballyPositioned { backdrop.coordinates = it }
        .drawWithContent {
            backdrop.layer.record(this, layoutDirection, size.toIntSize()) {
                this@drawWithContent.drawContent()
            }
            backdrop.hasContent = true
            drawLayer(backdrop.layer)
        }

@Immutable
data class GlassStyle(
    val blur: Dp = 4.dp,
    /** Max sampling displacement at the very edge (the "lens" strength). */
    val refraction: Dp = 16.dp,
    /** Width of the refractive bevel measured from the edge inward. */
    val bevel: Dp = 24.dp,
    val chroma: Float = 0.05f,
    val saturation: Float = 1.35f,
    val brightness: Float = 0.02f,
)

object LiquidGlassDefaults {
    val Bar = GlassStyle()
    val Card = GlassStyle(blur = 8.dp, refraction = 10.dp, bevel = 18.dp, chroma = 0.03f, saturation = 1.25f)
}

@Composable
fun liquidGlassTint(): Color {
    val dark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    return if (dark) Color.White.copy(alpha = 0.07f) else Color.White.copy(alpha = 0.30f)
}

/**
 * Turns this element into liquid glass: refracts + blurs the [backdrop] behind it,
 * tints it and draws a specular rim. The element's own content is drawn on top.
 */
@Composable
fun Modifier.liquidGlass(
    shape: Shape,
    style: GlassStyle = LiquidGlassDefaults.Bar,
    tint: Color = liquidGlassTint(),
    backdrop: GlassBackdrop? = LocalGlassBackdrop.current,
): Modifier {
    val layer = rememberGraphicsLayer()
    var offset by remember { mutableStateOf(Offset.Zero) }
    val cache = remember { GlassEffectCache() }
    val fallbackColor = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.88f)

    return this
        .onGloballyPositioned { coords ->
            val src = backdrop?.coordinates
            if (src != null && src.isAttached && coords.isAttached) {
                val p = src.localPositionOf(coords, Offset.Zero)
                if (p != offset) offset = p
            }
        }.clip(shape)
        .drawWithContent {
            val outline = shape.createOutline(size, layoutDirection, this)
            val canRefract =
                backdrop != null &&
                    backdrop.hasContent &&
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                    size.minDimension > 1f

            if (canRefract && backdrop != null) {
                val radii = shapeRadii(shape, size, layoutDirection, this)
                layer.renderEffect =
                    cache.get(
                        size = size,
                        radii = radii,
                        blurPx = style.blur.toPx(),
                        refractionPx = style.refraction.toPx(),
                        bevelPx = style.bevel.toPx(),
                        chroma = style.chroma,
                        saturation = style.saturation,
                        brightness = style.brightness,
                    )
                layer.clip = true
                layer.record(this, layoutDirection, size.toIntSize()) {
                    translate(-offset.x, -offset.y) {
                        drawLayer(backdrop.layer)
                    }
                }
                drawLayer(layer)
                drawRect(tint)
            } else {
                drawRect(fallbackColor)
                drawRect(tint)
            }

            // Specular rim: bright on the light side, faint on the other.
            drawPath(
                path = outlineToPath(outline),
                brush =
                    Brush.linearGradient(
                        colors =
                            listOf(
                                Color.White.copy(alpha = 0.60f),
                                Color.White.copy(alpha = 0.06f),
                                Color.White.copy(alpha = 0.02f),
                                Color.White.copy(alpha = 0.30f),
                            ),
                        start = Offset.Zero,
                        end = Offset(size.width, size.height),
                    ),
                style = Stroke(width = 2.dp.toPx()),
            )
            drawContent()
        }
}

/** Convenience container. */
@Composable
fun GlassBox(
    modifier: Modifier = Modifier,
    shape: Shape,
    style: GlassStyle = LiquidGlassDefaults.Bar,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(modifier = modifier.liquidGlass(shape, style), content = content)
}

/**
 * Colourful soft background so that glass has something to refract on plain screens
 * (settings, library, etc.). Draws into [backdrop] so children can sample it.
 */
@Composable
fun GlassAmbientBackground(
    backdrop: GlassBackdrop,
    pureBlack: Boolean,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val base = if (pureBlack) Color.Black else cs.surface
    val dark = base.luminance() < 0.5f
    val a = if (dark) 0.42f else 0.30f
    val c1 = cs.primary
    val c2 = cs.tertiary
    val c3 = cs.secondary
    Box(
        modifier =
            modifier
                .fillMaxSize()
                .glassSource(backdrop)
                .drawBehind {
                    drawRect(base)
                    val w = size.width
                    val h = size.height
                    drawCircle(
                        brush = Brush.radialGradient(listOf(c1.copy(alpha = a), Color.Transparent), Offset(w * 0.10f, h * 0.10f), w * 0.85f),
                        radius = w * 0.85f,
                        center = Offset(w * 0.10f, h * 0.10f),
                    )
                    drawCircle(
                        brush = Brush.radialGradient(listOf(c2.copy(alpha = a), Color.Transparent), Offset(w * 0.95f, h * 0.45f), w * 0.80f),
                        radius = w * 0.80f,
                        center = Offset(w * 0.95f, h * 0.45f),
                    )
                    drawCircle(
                        brush = Brush.radialGradient(listOf(c3.copy(alpha = a), Color.Transparent), Offset(w * 0.20f, h * 0.92f), w * 0.90f),
                        radius = w * 0.90f,
                        center = Offset(w * 0.20f, h * 0.92f),
                    )
                },
    )
}

private fun outlineToPath(outline: Outline): Path =
    when (outline) {
        is Outline.Rectangle -> Path().apply { addRect(outline.rect) }
        is Outline.Rounded -> Path().apply { addRoundRect(outline.roundRect) }
        is Outline.Generic -> outline.path
    }

private fun shapeRadii(
    shape: Shape,
    size: Size,
    direction: LayoutDirection,
    density: androidx.compose.ui.unit.Density,
): FloatArray {
    val maxR = size.minDimension / 2f
    val r =
        if (shape is CornerBasedShape) {
            val ts = shape.topStart.toPx(size, density)
            val te = shape.topEnd.toPx(size, density)
            val be = shape.bottomEnd.toPx(size, density)
            val bs = shape.bottomStart.toPx(size, density)
            if (direction == LayoutDirection.Ltr) {
                floatArrayOf(ts, te, be, bs)
            } else {
                floatArrayOf(te, ts, bs, be)
            }
        } else {
            floatArrayOf(maxR, maxR, maxR, maxR)
        }
    for (i in r.indices) r[i] = r[i].coerceIn(0f, maxR)
    return r // order: top-left, top-right, bottom-right, bottom-left
}

/** Re-creates the RenderEffect only when parameters change. */
private class GlassEffectCache {
    private var key: Int = 0
    private var effect: RenderEffect? = null

    fun get(
        size: Size,
        radii: FloatArray,
        blurPx: Float,
        refractionPx: Float,
        bevelPx: Float,
        chroma: Float,
        saturation: Float,
        brightness: Float,
    ): RenderEffect? {
        var k = size.width.hashCode()
        k = 31 * k + size.height.hashCode()
        k = 31 * k + radii.contentHashCode()
        k = 31 * k + blurPx.hashCode()
        k = 31 * k + refractionPx.hashCode()
        k = 31 * k + bevelPx.hashCode()
        k = 31 * k + chroma.hashCode()
        k = 31 * k + saturation.hashCode()
        k = 31 * k + brightness.hashCode()
        if (effect != null && k == key) return effect

        effect =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                buildShaderEffect(size, radii, blurPx, refractionPx, bevelPx, chroma, saturation, brightness)
            } else {
                // API 31-32: blur only (no AGSL available)
                BlurEffect(blurPx.coerceAtLeast(1f), blurPx.coerceAtLeast(1f), TileMode.Clamp)
            }
        key = k
        return effect
    }

    @androidx.annotation.RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private fun buildShaderEffect(
        size: Size,
        radii: FloatArray,
        blurPx: Float,
        refractionPx: Float,
        bevelPx: Float,
        chroma: Float,
        saturation: Float,
        brightness: Float,
    ): RenderEffect {
        val shader = RuntimeShader(GLASS_AGSL)
        shader.setFloatUniform("size", size.width, size.height)
        shader.setFloatUniform("radii", radii[0], radii[1], radii[2], radii[3])
        shader.setFloatUniform("refraction", refractionPx)
        shader.setFloatUniform("bevel", bevelPx.coerceAtLeast(1f))
        shader.setFloatUniform("chroma", chroma)
        shader.setFloatUniform("saturation", saturation)
        shader.setFloatUniform("brightness", brightness)
        val shaderEffect = AndroidRenderEffect.createRuntimeShaderEffect(shader, "content")
        val result =
            if (blurPx >= 0.5f) {
                val blur = AndroidRenderEffect.createBlurEffect(blurPx, blurPx, Shader.TileMode.CLAMP)
                AndroidRenderEffect.createChainEffect(shaderEffect, blur)
            } else {
                shaderEffect
            }
        return result.asComposeRenderEffect()
    }
}

private const val GLASS_AGSL = """
uniform shader content;
uniform float2 size;
uniform float4 radii;      // top-left, top-right, bottom-right, bottom-left (px)
uniform float refraction;  // px
uniform float bevel;       // px
uniform float chroma;
uniform float saturation;
uniform float brightness;

float cornerR(float2 p) {
    if (p.y < 0.0) {
        return (p.x < 0.0) ? radii.x : radii.y;
    }
    return (p.x < 0.0) ? radii.w : radii.z;
}

float sdRoundBox(float2 p, float2 hs) {
    float r = cornerR(p);
    float2 q = abs(p) - hs + float2(r);
    return min(max(q.x, q.y), 0.0) + length(max(q, float2(0.0))) - r;
}

half4 main(float2 fc) {
    float2 hs = size * 0.5;
    float2 p = fc - hs;
    float d = sdRoundBox(p, hs);               // < 0 inside the shape

    float2 gx = float2(1.0, 0.0);
    float2 gy = float2(0.0, 1.0);
    float2 g = float2(
        sdRoundBox(p + gx, hs) - sdRoundBox(p - gx, hs),
        sdRoundBox(p + gy, hs) - sdRoundBox(p - gy, hs)
    );
    float2 n = g / max(length(g), 0.0001);     // outward normal

    float t = clamp(-d / bevel, 0.0, 1.0);     // 0 at the edge, 1 deep inside
    float bend = pow(1.0 - t, 2.5);            // strong near the edge only
    float2 disp = -n * bend * refraction;      // sample from further inside

    float2 lo = float2(0.5);
    float2 hi = size - float2(0.5);
    float2 sg = clamp(fc + disp, lo, hi);
    float2 sr = clamp(fc + disp * (1.0 + chroma * 6.0), lo, hi);
    float2 sb = clamp(fc + disp * (1.0 - chroma * 6.0), lo, hi);

    half4 cg = content.eval(sg);
    half3 col = half3(content.eval(sr).r, cg.g, content.eval(sb).b);

    half l = dot(col, half3(0.299, 0.587, 0.114));
    col = mix(half3(l), col, half(saturation)) + half(brightness);

    // inner specular glow on the bevel (light from the top-left)
    float rim = pow(1.0 - t, 4.0);
    float lit = max(dot(n, normalize(float2(-0.6, -0.8))), 0.0)
              + 0.35 * max(dot(n, normalize(float2(0.6, 0.8))), 0.0);
    col += half(rim * lit * 0.30);

    return half4(col, cg.a);
}
"""
